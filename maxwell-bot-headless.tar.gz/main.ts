import { Bot } from "./bot.ts";

const bot = new Bot()