import MessagePack from 'msgpack-lite';
import handleEvent from "./handleEventTypes.ts";
import { Vector3, Vector4 } from "./vectors.ts";
import { EventEmitter } from "node:events";
import { Buffer } from "node:buffer";

class GObject {
    position: Vector3 = new Vector3(0, 0, 0);
    quaternion: Vector4 = new Vector4(0, 0, 0, 0);
}

class BotEvents extends EventEmitter {
 
}

export class Cat extends GObject {
    uuid: string = "";
    name: string = "";
    flagEmoji: string = "";
    latestEvent: number = 0;
    constructor(name?: string) {
        super()
        this.name = name ?? ""
    }
    setPosition(x: number, y: number, z: number, t: number) {
        if (t < this.latestEvent) return
        this.latestEvent = t
        this.position.set(x,y,z)
    }

    setQuaternion(x: number, y: number, z: number, w: number, t: number) {
        if (t < this.latestEvent) return
        this.latestEvent = t
        this.quaternion.set(x, y, z, w)
    }
}

export class Rat extends GObject {
    setPosition(x: number, y: number, z: number) {
        this.position.set(x,y,z)
    }
    setQuaternion(x: number, y: number, z: number, w: number) {
        this.quaternion.set(x, y, z, w)
    }
}

export class Bot {
    ws = new WebSocket("wss://worlds.twotwelve.uk/ws");
    uuid = null;
    world = new Map<string, Cat>();
    cat = new Cat("");
    nameToken?: string = undefined;
    targetToken: string = "";
    rat: Rat = new Rat();

    events = new BotEvents()
    async onmessage (event: MessageEvent) {
        let eventPayload
        if (event.data instanceof Blob) {
            const ab = Buffer.from(await event.data.arrayBuffer())
            // console.log(ab)
            eventPayload = MessagePack.decode(ab)
        } else {
            eventPayload = JSON.parse(event.data)
        }
        if (!eventPayload) {
            console.log("Malformed event data:", event.data)
            return
        }
        console.log("got", eventPayload.type, "packet")
        handleEvent(eventPayload, this)
    }

    onclose () {
        console.info("Websocket connection closed, reopening");
        this.ws = new WebSocket("wss://worlds.twotwelve.uk/ws");
        this.initWebsockets(this)
    }

    initWebsockets(bot: Bot) {
        this.ws.addEventListener("message", (event: MessageEvent) => {this.onmessage.call(bot, event)});
        this.ws.addEventListener("open",  ()=>{console.info("Websocket connection opened")})
        this.ws.addEventListener("close", ()=>this.onclose.call(bot))
    }

    constructor () {
        this.initWebsockets(this);
    }
}