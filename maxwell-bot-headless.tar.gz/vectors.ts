export class Vector3 {
    x = 0;
    y = 0;
    z = 0;
    constructor (x=0, y=0, z=0) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    set (x?: number, y?: number, z?: number) {
        if(x) this.x = x;
        if(y) this.y = y;
        if(z) this.z = z;
    }
    clone() {
        return new Vector3(this.x, this.y, this.z)
    }
}

export class Vector4 { // AKA quaternion
    x = 0;
    y = 0;
    z = 0;
    w = 0;
    constructor (x=0, y=0, z=0, w=0) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }
    set (x?: number, y?: number, z?: number, w?: number) {
        if(x) this.x = x;
        if(y) this.y = y;
        if(z) this.z = z;
        if(w) this.w = w;
    }
    clone() {
        return new Vector4(this.x, this.y, this.z, this.w)
    }
}